const express = require('express');
const { Console } = require("console");
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient
const app = express();

class toDoList {
    constructor(_id, taskTitle, insertdate, isCompleted){
        this._id = _id;
        this.taskTitle = taskTitle;
        this.insertdate = insertdate;
        this.isCompleted = isCompleted;
    } 
}

const uri = "mongodb+srv://yeruult:91583303@cluster0.dapql.mongodb.net/shalgalt_list?retryWrites=true&w=majority";

const client = new MongoClient(uri, {useNewUrlParser: true, useUnifiedTopology: true});

const collection = client.db("shalgalt_list").collection("list");

// Make sure you place body-parser before your CRUD handlers!
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.use(express.static('views'));
app.use(express.static('/public/style.css'));
app.use(express.static('/CSS'));
app.use('/CSS', express.static(__dirname + '/CSS/style.css'));

app.get("/", function(req, res) {
    const client = new MongoClient(uri, {useNewUrlParser: true, useUnifiedTopology: true});
    let blog_arr = [];
    client.connect((error, result) => {
        const collection = client.db("shalgalt_list").collection("list");
        collection.find().toArray().then( result => {
            list_arr = result.slice();
        }).catch(error => console.error(error))
    });
    
    console.log(list_arr);
    client.close();
    res.render('home', {blogs: blog_arr});
});
app.get("/home", function(req,res) {
    res.sendFile(__dirname + "/home.html")
});
app.post("/", function(req, res) {
    var _taskTitle = "ehniiTask"
    var _insertDate = Date.now()
    var _isCompleted = "1"

    client.connect((error, result ) =>{
        const collection = client.db("shalgalt_list").collection("list");
        collection.insertOne({id: 1, taskTitle: "daraahTask", insertdate: Date.now(), isCompleted: true}).then(result => { console.log(result)}).catch(error=>console.error(error));
        client.close();
    })

});

app.listen(3000, function() {
    console.log('Starting server at port 3000')
});